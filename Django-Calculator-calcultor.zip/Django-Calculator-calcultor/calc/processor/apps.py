from django.apps import AppConfig


class ProcessorConfig(AppConfig):
    name = 'processor'
