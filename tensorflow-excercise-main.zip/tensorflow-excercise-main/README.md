# tensorflow-excercise
this repo have excercise of tensorflow
