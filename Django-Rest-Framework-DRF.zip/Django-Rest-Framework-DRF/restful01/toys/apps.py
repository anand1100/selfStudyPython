from django.apps import AppConfig


class ToysConfig(AppConfig):
    name = 'toys'
