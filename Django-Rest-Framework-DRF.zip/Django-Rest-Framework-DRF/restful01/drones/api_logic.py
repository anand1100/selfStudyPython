from drones.models import DroneCategory , Drone , Piolt  , Competition
from drones.serializers import DroneCategorySerializer , DroneSerializer , PioltSerializer , CompetitionSerializer



