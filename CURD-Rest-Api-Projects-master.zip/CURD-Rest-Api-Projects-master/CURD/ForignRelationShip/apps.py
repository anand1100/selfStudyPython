from django.apps import AppConfig


class ForignrelationshipConfig(AppConfig):
    name = 'ForignRelationShip'
