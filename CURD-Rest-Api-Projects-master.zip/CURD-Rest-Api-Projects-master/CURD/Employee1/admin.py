from django.contrib import admin
from Employee1.models import EmployeeProfile

admin.site.register(EmployeeProfile)










