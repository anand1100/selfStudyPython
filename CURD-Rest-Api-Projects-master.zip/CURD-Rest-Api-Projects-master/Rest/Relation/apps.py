from django.apps import AppConfig


class RelationConfig(AppConfig):
    name = 'Relation'
