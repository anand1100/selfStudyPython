from django.apps import AppConfig


class ClassapiConfig(AppConfig):
    name = 'ClassApi'
