from django.apps import AppConfig


class GenericapiConfig(AppConfig):
    name = 'GenericApi'
