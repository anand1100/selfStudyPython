import cmath
a=float(input("Enter The First Quardinate"))
b=float(input("Enter The Second Quardinate"))
c=float(input("Enter The Third Quardinate"))
root1=((-1*b)-cmath.sqrt((b**2)-(4*a*c)))/(2*a)
root2=((-1*b)+cmath.sqrt((b**2)-(4*a*c)))/(2*a)
print("Root-1::",root1)
print("Root-2::",root2)
this is Appending this is again appending strings in filethis is 3rd times appending