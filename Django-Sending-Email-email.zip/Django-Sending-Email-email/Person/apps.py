from django.apps import AppConfig


class PersonConfig(AppConfig):
    name = 'Person'
