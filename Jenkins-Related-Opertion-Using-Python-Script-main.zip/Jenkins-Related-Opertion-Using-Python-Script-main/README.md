# Jenkins-Related-Operation-Using-Python-Script
this repo contains bascially jenkins related operation using python you can perform easily with help of python few packages
