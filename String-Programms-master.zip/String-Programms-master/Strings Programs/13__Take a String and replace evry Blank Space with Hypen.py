string=input("Enter The String::")
new=string.replace(' ',"-")
print("Your New String::",new)
