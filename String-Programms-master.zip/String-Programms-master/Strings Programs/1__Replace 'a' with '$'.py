a=input("Enter The String::")
b=a.replace('a','$')
print("Your New String::",b)
