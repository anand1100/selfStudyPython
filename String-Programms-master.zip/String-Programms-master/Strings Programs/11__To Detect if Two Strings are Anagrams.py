a=input("Enter the 1st String::")
b=input("Enter The 2nd String")
if(sorted(a)==sorted(b)):
    print("String is Anagrams")
else:
    print("String is Not Anagrams")
    
