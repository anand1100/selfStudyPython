string=input("Enter The String::")
count=0
for i in string:
    count=count+1
print("Total Length ofString:::",count)
