string=input("Enter The String::")
substring=input("Enter The Word::")
if(string.find(substring)==-1):
    print("Substring Not Found in String")
else:
    print("Substring Found in String")
