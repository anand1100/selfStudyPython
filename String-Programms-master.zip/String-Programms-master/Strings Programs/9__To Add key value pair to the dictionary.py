key=int(input("Enter The Keys::"))
value=int(input("Enter The Values"))
d={}
d.update({key:value})
print(d)
