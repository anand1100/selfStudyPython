.. django-allauth documentation master file, created by
   sphinx-quickstart on Wed Jun  6 22:58:42 2012.

.. include:: ../README.rst

Contents
========

.. toctree::
   :maxdepth: 2

   overview
   installation
   configuration
   providers
   signals
   views
   forms
   templates
   decorators
   advanced
   faq
   release-notes
   support


==================
Indices and tables
==================

* :ref:`genindex`
* :ref:`search`
