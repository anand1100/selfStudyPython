# DBMS_SQL-Notes
DBMS_SQL Notes

- GitHub Repo : https://github.com/riti2409/DBMS_SQL-Notes

- Source : https://www.youtube.com/playlist?list=PLxCzCOWd7aiFAN6I8CuViBuCdJgiOkT2Y (Gate Smashers)

  https://www.youtube.com/playlist?list=PLL8qj6F8dGlSZYUFrX6ASTdFWiUlLjguc (Tutorials space)

- PDF(of notes): https://drive.google.com/file/d/1XGU4dusm9IV2DzBnuKhrrM_o7hUIt7NT/view?usp=sharing

- For Practice : https://www.hackerrank.com/domains/sql

- ![sql-basics-cheat-sheet-a4-page-1](https://user-images.githubusercontent.com/65703138/150641076-dd864e47-41fd-46e5-87a5-6e4c34326c96.png)

- ![sql-basics-cheat-sheet-a4-page-2](https://user-images.githubusercontent.com/65703138/150641077-f19c4ada-751b-4117-ae25-a3c573928c80.png)

- Blogs
1) [Geeks for geeks](https://www.geeksforgeeks.org/sql-tutorial/)
2) [w3-schools](https://www.w3schools.com/sql/)
3) [tutorials Point](https://www.tutorialspoint.com/sql/index.htm)

Would love if you add more in the list :)
