##apache-settings.txt
This information goes into /etc/apache2/sites-available/default

##django.wsgi
This entire file should be copiedto /home/ubuntu/todo-django/django.wsgi

If you install it in a different path or as a different user, you will need to update the apache settings accordingly.
