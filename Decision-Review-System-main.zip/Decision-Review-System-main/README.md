# Decision-Review-System
I have created a personalized decision review system using (Python- Tkinter, openCV)
